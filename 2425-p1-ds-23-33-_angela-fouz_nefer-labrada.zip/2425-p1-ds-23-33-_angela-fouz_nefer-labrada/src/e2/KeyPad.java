
package e2;

import java.util.HashSet;
import java.util.Set;

public class KeyPad {

    // constructor del keypad
    // detecta si el input es nulo o si no tiene longitud
    public KeyPad(char[][] input) {
        if (input == null || input.length == 0) {
            throw new IllegalArgumentException("Input nulo. Intente de nuevo.");
        }
    }

    // metodo que comprueba si la matriz es válida
    public static boolean isValidKeyPad(char[][] matrix) {
        // Validación inicial de la matriz y la primera fila
        if (matrix == null || matrix.length == 0 || matrix[0] == null) {
            return false;
        }

        int rowLength = matrix[0].length;  // Longitud de la primera fila

        Set<Character> dup = new HashSet<>();  // Para detectar duplicados

        for (char[] row : matrix) {
            // Validar que cada fila no sea nula y que todas las filas tengan la misma longitud
            if (row == null || row.length != rowLength) {
                return false;  // Devuelve false si alguna fila es nula o tiene longitud diferente
            }
            for (char element : row) {
                // Validar que cada elemento sea un número o una letra mayúscula
                if (!((element >= '0' && element <= '9') || (element >= 'A' && element <= 'Z'))) {
                    return false;  // Devuelve false si el elemento no es válido
                }
                // Verificar duplicados
                if (!dup.add(element)) {
                    return false;  // Devuelve false si hay un duplicado
                }
            }
        }
        return true;  // Devuelve true si todo es válido
    }

    // metodo que comprueba si los movimientos son validos
    public static boolean areValidMovements(String[] movements) {
        if (movements == null) return false;
        final String allowed = "UDLR";  // string con los movimientos permitidos

        // Recorre cada movimiento en el arreglo y sus elementos, comprobando que sean como allowed dice
        for (String move : movements) {
            if (move == null || move.isEmpty()) {
                return false;
            }
            for (char ch : move.toCharArray()) {
                if (!allowed.contains(String.valueOf(ch))) {
                    return false;
                }
            }
        }
        return true;
    }

    // metodo que convierte el input en movimientos
    public static String obtainCode(char[][] userInput, String[] movements) {
        // si no se cumplen lo anteriores metodos
        if (!isValidKeyPad(userInput) || !areValidMovements(movements)) {
            throw new IllegalArgumentException("Teclado o movimientos inválidos.");
        }
        // creamos un builder
        StringBuilder key = new StringBuilder();
        int x = 0, y = 0;
        // bucle que recorre cada elemento del input
        for (String coords : movements) {
            // eliminé el append aquí que me ponía uno extra
            // Procesar los movimientos
            for (char direction : coords.toCharArray()) {
                switch (direction) {
                    case 'U':
                        if (y > 0) y--;
                        break;
                    case 'D':
                        if (y < userInput.length - 1) y++;
                        break;
                    case 'L':
                        if (x > 0) x--;
                        break;
                    case 'R':
                        if (x < userInput[y].length - 1) x++;
                        break;
                }
            }
            // añade la última posición, lo movi aqui para mejorar el flujo
            key.append(userInput[y][x]);
        }
        return key.toString();
    }
}

package e3;

public enum PropertyType {
    APARTMENT,
    HOUSE,
    LOCAL
}

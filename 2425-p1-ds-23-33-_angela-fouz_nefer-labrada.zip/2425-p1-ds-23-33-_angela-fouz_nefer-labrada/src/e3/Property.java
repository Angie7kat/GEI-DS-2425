package e3;

public class Property {
    // Definimos los datos de la propiedad
    final String catastro;
    final PropertyType tipo;
    final String direccion;
    final String codigoPostal;
    final int dimensiones;
    final int habitaciones;
    final int banos;

    // Constructor de la propiedad
    public Property(PropertyType catastro, String tipo, String direccion,
                    String codigoPostal, int dimensiones, int habitaciones, int banos) {
        this.catastro = String.valueOf(catastro);
        this.tipo = PropertyType.valueOf(tipo);
        this.direccion = direccion;
        this.codigoPostal = codigoPostal;
        this.dimensiones = dimensiones;
        this.habitaciones = habitaciones;
        this.banos = banos;
    }

    // Getters, para poder acceder a los datos
    public String getCatastro() {return catastro;}
    public PropertyType getTipo() {return tipo;}
    public String getDireccion() {return direccion;}
    public String getCodigoPostal() {return codigoPostal;}
    public int getDimensiones() {return dimensiones;}
    public int getHabitaciones() {return habitaciones;}
    public int getBanos() {return banos;}

    // cambiamos la funcion toString para que ponga los datos mas ordenados
    @Override
    public String toString() {
        return tipo + "\n" + catastro + "\n" + direccion + "\n" + codigoPostal + "\n"
                + dimensiones + "\n" + habitaciones + "\n" + banos;
    }

    // cambiamos el equals para que tambien mire si sus catastros son iguales
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        Property p = (Property) obj;
        return catastro.equals(p.catastro);
    }

    // cambiamos el hashCode para que se aplique a si sus catastros son iguales (mismo objeto)
    @Override
    public int hashCode() {
        int hash = 17;
        hash = 31 * hash + (catastro != null ? catastro.hashCode() : 0);
        return hash;
    }
}



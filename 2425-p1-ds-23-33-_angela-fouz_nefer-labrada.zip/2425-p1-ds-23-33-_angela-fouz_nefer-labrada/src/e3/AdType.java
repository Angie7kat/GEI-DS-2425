package e3;

public enum AdType {
    RENTAL,
    PURCHASE,
}

package e3;

public class Ad {
    // Clase Ad y sus datos principales
    private String agencia;
    private Property propiedad;
    private AdType tipoAnuncio;
    private double valor;

    // Constructor
    public Ad(String agencia, Property propiedad, AdType tipoAnuncio, double valor) {
        this.agencia = agencia;
        this.propiedad = propiedad;
        this.tipoAnuncio = tipoAnuncio;
        this.valor = valor;
    }

    // setter
    public Ad(Ad a) {
        this.agencia = a.agencia;
        this.propiedad = a.propiedad;
        this.tipoAnuncio = a.tipoAnuncio;
        this.valor = a.valor;
    }

    public String getAgencia() {return agencia;}
    public AdType getTipoAnuncio() {return tipoAnuncio;}
    public Property getPropiedad() {return propiedad;}
    public double getValor() {return valor;}

    @Override
    public String toString() {
        return agencia + "\n" + tipoAnuncio + "\n" + propiedad + "\n" + valor;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        Ad a = (Ad) obj;
        return propiedad.equals(a.getPropiedad()) && valor == a.getValor();
    }

    public boolean isPropertyEqual(Ad a) {
        if (a == null) {
            return false;
        }
        return this.propiedad.equals(a.getPropiedad());
    }

    public boolean isPriceNormal(){
        if (this.valor < 9999 || this.valor > 999999){
            return false;
        } else
            return true;
    }

    public double priceMetersEuros(){
        int metros = this.propiedad.getDimensiones();
        if (metros > 0){
            throw new IllegalArgumentException("Dimensiones invalidas");
        } else return valor / metros;
    }

    public double dropPrice(int precio){
        return precio * 0.25;
    }

    public double getPriceInEuros(){
        //asumo que el precio original es en dolares
        return this.valor * 0.91;
    }


}

[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/59h-drD0)
## Estudiantes - Students  

Ángela Fouz

Nefer Labrada

## Diseño Software - Prácticas  

El enunciado de las distintas prácticas se encuentra en la página de la asignatura del Campus Virtual

## Software Design - Assignments

The different assignment statements are available on the course page of the Virtual Campus
